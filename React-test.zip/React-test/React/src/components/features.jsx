import React, { Component } from "react";

export class features extends Component {
  render() {
    return (
      <div id="features" className="text-center">
        <div >
          <div className="col-md-10 col-md-offset-1 section-title">
          <span class="glyphicon glyphicon-star"></span>
		      <span class="glyphicon glyphicon-star"></span>
		      <span class="glyphicon glyphicon-star"></span>
		      <span class="glyphicon glyphicon-star"></span>
		      <span class="glyphicon glyphicon-star"></span>
            <p>"This is the best towel set I've ever had; it's cool,comfortable and aesthetically perfect."</p>
            <p><a href="#testimonials" class="btn btn-lg btn-secondary btn-gallery">READ TESTIMONIALS</a></p>
            <p>FOLLOW US ON <a href="https://instagram.com"> <i class="fa fa-instagram"></i>  </a></p>
            
          </div>
          <div className="row">
            {this.props.data
              ? this.props.data.map((d,i) => (
                  <div  key={`${d.title}-${i}`} className="col-xs-4 col-md-3">
                  <div className="thumbnail">
                    {" "}
                    <img src={d.img} alt="..." className="services-img" />
                    <h3>{d.title}</h3>
                    <p>{d.text}</p>
                    </div>
                  </div>
                ))
              : "Loading..."}
          </div>
        </div>
      </div>
    );
  }
}

export default features;
