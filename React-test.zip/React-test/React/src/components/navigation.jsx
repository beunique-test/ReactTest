import React, { Component } from "react";

export class Navigation extends Component {
  render() {
    return (
      <nav id="menu" className="navbar navbar-default navbar-fixed-top">
        <div >


          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-brand-centered">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>

            <img src="img/portfolio/logo.png" class="img-responsive navbar-brand navbar-brand-centered" alt="Responsive">
            </img>


          </div>


          <div class="collapse navbar-collapse" id="navbar-brand-centered">
            <ul class="nav navbar-nav">
              <li> <a href="#portfolio" className="page-scroll">
                SHOP
                </a>
              </li>
              <li>
                <a href="#testimonials" className="page-scroll">
                  OUR STORY
            </a>
              </li>
              <li>
                <a href="#team" className="page-scroll">
                  EXPERTIS
                </a>
              </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
              <li>
                <a href="#contact" className="page-scroll">
                  CONTACT
            </a>
              </li>
              <li><a href="#contact"><i class="fa fa-fw fa-search"></i></a></li>
              <li><a href="#features"><i class="fa fa-fw fa-user"></i></a></li>
              <li><a href="#contact"><i class="fa fa-fw fa-shopping-cart"></i></a></li>
              
            </ul>
          </div>
        </div>
      </nav>


    );
  }
}

export default Navigation;
