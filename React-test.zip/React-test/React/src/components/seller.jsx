import React, { Component } from "react";

export class Seller extends Component {
  render() {
    return (
      <div id="team" className="text-center">
        <div className="container">
          <div className="col-md-8 col-md-offset-2 section-title">
            <h2>Best Seller</h2>
            
          </div>
          <div id="row">
            {this.props.data
              ? this.props.data.map((d, i) => (
                  <div  key={`${d.name}-${i}`} className="col-md-4 col-sm-6 team">
                    <div className="thumbnail">
                      {" "}
                      <img src={d.img} alt="..." className="team-img" />
                      <div className="caption">
                        <h4 style={{float:"left"}}>{d.name}</h4><br></br>                     
                        <h4 style={{float:"left"}}>{d.price} </h4><br></br> 
                        <p style={{float:"left"}}>{d.offer}</p>
                       
                      </div>
                    </div>
                  </div>
                ))
              : "loading"}
          </div>
        </div>
      </div>
    );
  }
}

export default Seller;
