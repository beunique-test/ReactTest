import React, { Component } from "react";

export class Gallery extends Component {
  render() {
    return (
      <div id="portfolio" className="text-center">
        <div className="container">
          <div className="section-title">
            
            <p>
             Our premium products got the finest quality cotton that create an exquisite lightweight
            textile that’s both soft and crisp – guaranteed to give you a wonderful night’s sleep
            </p>
          </div>
          <div className="row">
            <div className="portfolio-items">
              <div className="col-sm-6 col-md-6 col-lg-6">
                <div className="portfolio-item">
                  <div  class="reasons-col animate-onscroll fadeIn">
                    {" "}
                    <a
                      href="img/portfolio/img-main1.jpg"
                      title="Shop Bed Linens"
                      data-lightbox-gallery="gallery1"
                    >
                    <div class="reasons-titles">
                       <a href="#" class="btn btn-lg btn-secondary btn-gallery">Shop Bed Linens</a>
						
                    </div>
                      <img
                        src="img/portfolio/img-main1.jpg"
                        className="img-responsive"
                        alt="Project Title"
                      />{" "}
                    </a>{" "}
                  </div>
                </div>
              </div>
              <div className="col-sm-6 col-md-6 col-lg-6">
                <div className="portfolio-item">
                  <div class="reasons-col animate-onscroll fadeIn">
                    {" "}
                    <a
                      href="img/portfolio/img-main2.jpg"
                      title="Shop Bath Towels"
                      data-lightbox-gallery="gallery1"
                    >
                      <div class="reasons-titles">
                       <a href="#" class="btn btn-lg btn-secondary btn-gallery">Shop Bath Towels</a>
                      </div>
                      <img
                        src="img/portfolio/img-main2.jpg"
                        className="img-responsive"
                        alt="Project Title"
                      />{" "}
                    </a>{" "}
                  </div>
                </div>
              </div>
              <div className="col-sm-6 col-md-6 col-lg-6" style={{float: "right"}}>
                <div className="portfolio-item">
                  <div class="reasons-col animate-onscroll fadeIn">
                    {" "}
                    <a
                      href="img/portfolio/img-main3.jpg"
                      title="Shop Bath Robes"
                      data-lightbox-gallery="gallery1"
                    >
                      <div class="reasons-titles">
                       <a href="#" class="btn btn-lg btn-secondary btn-gallery">Shop Bath Robes</a>
                      </div>
                      <img
                        src="img/portfolio/img-main3.jpg"
                        className="img-responsive"
                        alt="Project Title"
                      />{" "}
                    </a>{" "}
                  </div>
                </div>
              </div>
              <div className="col-sm-6 col-md-6 col-lg-6">
                <div className="portfolio-item">
                  <div class="reasons-col animate-onscroll fadeIn">
                    {" "}
                    <a
                      href="img/portfolio/img-main4.jpg"
                      title="Shop Bath Fragrance"
                      data-lightbox-gallery="gallery1"
                    >
                      <div class="reasons-titles">
                       <a href="#" class="btn btn-lg btn-secondary btn-gallery">Shop Bath Fragrance</a>
                      </div>
                      <img
                        src="img/portfolio/img-main4.jpg"
                        className="img-responsive"
                        alt="Project Title"
                      />{" "}
                    </a>{" "}
                  </div>
                </div>
              </div>
              
              
              
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Gallery;
