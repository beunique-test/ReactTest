import React, { Component } from "react";

export class Footer extends Component {
  render() {
    return (
      
      <div >
  <div class="row">
    	<div class="col-md-12">
    	    <footer class="footer">				
		<div class="container">
			<div class="row">
				<div class="col-md-3 m-b-30">
					<div class="footer-title m-t-5 m-b-20 p-b-8">
						OUR STORY
					</div>	
					<p class="white-text">
					Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
					</p>
          	<div class="footer-social-links m-t-30">
						<li>
							<a href="https://facebook.com">
								<i class="fa fa-facebook"></i>
							</a>
							<a href="https://twitter.com">
								<i class="fa fa-twitter"></i>
							</a>
							<a href="https://instagram.com">
								<i class="fa fa-instagram"></i>
							</a>
						</li>
					</div>
				</div>
				<div class="col-md-3 m-b-30">
					<div class="footer-title m-t-5 m-b-20 p-b-8">
					MORE..
					</div>	
					<div class="footer-links">
						<a href="#services">
							About Us
						</a>
						<a href="#contact">
							Contact Us
						</a>
						<a href="#features">
							Track My Order
						</a>
						<a href="#contact">
							FAQ
						</a>
					</div>
				</div>
				<div class="col-md-3 m-b-30">
					<div class="footer-title m-t-5 m-b-20 p-b-8">
						SHOP
					</div>	
					<div class="footer-links">
						<a href="#portfolio">
							Bed Linen
						</a>
						<a href="#portfolio">
						Bath Towel
						</a>
						<a href="#portfolio">
						Bathrobe
						</a>
						<a href="#portfolio">
						Home Fragrance
						</a>
					</div>
				</div>
				<div class="col-md-3 m-b-30">
					<div class="footer-title m-t-5 m-b-20 p-b-8">
						NEWSLETTER
					</div>	
					<div class="footer-links">
							<p class="white-text">
					subscribe to receive updates access to exclusive deals and more.
					</p>
          <input type="email" id="email" name="email" placeholder="Enter your email address"/><input type="button" value="Subscribe"/>
					</div>

				
				</div>
			</div>
      <div class="footer-bottom-left">
	  	Copyright © 2021, All Rights Reserved
      </div>
       <div class="footer-bottom-right">
    	<i class="fa fa-cc-mastercard" ></i>&nbsp;<i class="fa fa-cc-visa" ></i>&nbsp;<i class="fa fa-credit-card" ></i>
    	</div>
		</div>
	</footer>
	
    	</div>
	</div>
</div>

    );
  }
}
export default Footer;
