import React, { Component } from "react";

export class Header extends Component {
  render() {
    return (
      <header id="header">
        <div className="intro">
      
                  
          <div className="overlay">
            
            <div className="container">
            
              <div className="row">
             
                 <div className="col-md-8 col-md-offset-2 intro-text">
                  
                   <p><span>{this.props.data ? this.props.data.title : "Loading"}</span> </p>
                    
                  
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
    );
  }
}

export default Header;
